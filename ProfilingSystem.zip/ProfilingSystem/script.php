<script src = "plugins/js/admin.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>
