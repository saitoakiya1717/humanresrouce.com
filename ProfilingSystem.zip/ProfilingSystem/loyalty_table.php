<?php include ('header.php'); ?>
 <section class="content">
        <div class="container-fluid">
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                LOYALTY TABLE
                                <a href="#" data-toggle="modal" data-target="#profile_report"><p class="text-right print">Print</p></a>

                            </h2>
                        </div>
                              <div class="body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th >Name</th>
                                        <th >Year as of this moment</th>
                                        <th >Date 0f Original Appointment</th>
                                        <th >Years</th> 
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php include ('footer.php'); ?>